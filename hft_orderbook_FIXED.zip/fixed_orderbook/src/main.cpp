#include "Engine.h"
#include <iostream>
#include <string>
#include <cstdlib>

void printHelp() {
    std::cout << R"(
╔══════════════════════════════════════════════════════╗
║       HFT Limit Order Book  –  Usage Guide           ║
╠══════════════════════════════════════════════════════╣
║  ./orderbook [OPTIONS]                               ║
║                                                      ║
║  OPTIONS:                                            ║
║  --symbol   <STR>   Ticker symbol   (default: AAPL)  ║
║  --ops      <INT>   Target ops/sec  (default: 5000)  ║
║  --mid      <INT>   Mid price ticks (default: 15000) ║
║                     (ticks = cents, 15000=$150.00)   ║
║  --run      <INT>   Run seconds     (default: 30)    ║
║                     (0 = run forever)                ║
║  --display  <INT>   Print interval  (default: 2)     ║
║  --verbose          Print every trade                ║
║  --help             Show this help                   ║
╚══════════════════════════════════════════════════════╝
)";
}

int main(int argc, char* argv[]) {
    Engine::Config cfg;

    for (int i = 1; i < argc; ++i) {
        std::string arg(argv[i]);
        if (arg == "--help" || arg == "-h") { printHelp(); return 0; }
        else if (arg == "--symbol"  && i+1 < argc) cfg.symbol    = argv[++i];
        else if (arg == "--ops"     && i+1 < argc) cfg.targetOps = std::stoul(argv[++i]);
        else if (arg == "--mid"     && i+1 < argc) cfg.midPrice  = std::stoll(argv[++i]);
        else if (arg == "--run"     && i+1 < argc) cfg.runSecs   = std::stoi(argv[++i]);
        else if (arg == "--display" && i+1 < argc) cfg.displaySecs = std::stoi(argv[++i]);
        else if (arg == "--verbose")               cfg.verbose   = true;
        else { std::cerr << "Unknown arg: " << arg << "\n"; printHelp(); return 1; }
    }

    std::cout << R"(
 ██████╗ ██████╗ ██████╗ ███████╗██████╗     ██████╗  ██████╗  ██████╗ ██╗  ██╗
██╔═══██╗██╔══██╗██╔══██╗██╔════╝██╔══██╗    ██╔══██╗██╔═══██╗██╔═══██╗██║ ██╔╝
██║   ██║██████╔╝██║  ██║█████╗  ██████╔╝    ██████╔╝██║   ██║██║   ██║█████╔╝ 
██║   ██║██╔══██╗██║  ██║██╔══╝  ██╔══██╗    ██╔══██╗██║   ██║██║   ██║██╔═██╗ 
╚██████╔╝██║  ██║██████╔╝███████╗██║  ██║    ██████╔╝╚██████╔╝╚██████╔╝██║  ██╗
 ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚══════╝╚═╝  ╚═╝   ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝
                           HFT Limit Order Book  v1.0
)";

    Engine engine(cfg);
    engine.run();
    return 0;
}
